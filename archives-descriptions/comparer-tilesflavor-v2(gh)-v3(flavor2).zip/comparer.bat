@echo off
echo === Serveur local pour comparaison de tuiles ===
echo.
echo Arreter : Ctrl+C
echo Page : http://localhost:8080/compare.html
echo.
start http://localhost:8080/compare.html
python -m http.server 8080
pause
